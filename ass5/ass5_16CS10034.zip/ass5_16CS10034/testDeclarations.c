// TEST 2
// Declaration Phase
int test = 2;
double d = 1.25;
int i, w[25];
int a = 1, *p, b;
void func(int i, double d);
char c;

int main () {
	double e = 1.414;
	int f, w[8];
	int r = 5, *q, y;
	char h;
}