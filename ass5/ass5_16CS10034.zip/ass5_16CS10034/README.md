## MAKE:
make

## CALEN:
make clean

## RUN:
./a.out < <testfile>

## DEBUG:
./a.out DEBUG < <testfile>

--------------------------------------------------------

## CONSTRAINTS:

* 0 is not considered a integer constant
* Nextlist of last block item is not backpatched.
