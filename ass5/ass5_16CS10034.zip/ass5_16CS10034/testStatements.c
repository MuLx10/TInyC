// Test 2
int test = 2;
int add (int a, int b) {
	a = 25;
	int *x, y;
	x = &y;
	*x = y;
	y = *x;
}
void main () {
	int i, a[25], v = 5;
	double d;
	for (i=1; i<a[25]; i++) 
		i++;
	do i = i - 1; 
		while (a[i] < v);
	i = 3;
	if (i&&v) i = 1;
		return;
}